from setuptools import setup, find_packages

setup(
    name='one_step_frame',
    version='1.0.2',
    packages=find_packages(),
)
